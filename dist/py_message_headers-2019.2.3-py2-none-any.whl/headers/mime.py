# Generated on 2019-02-03T13:03:06.509000

# standard, [RFC4021]
CONTENT_ALTERNATIVE = "Content-Alternative"

# standard, [RFC4021]
CONTENT_DESCRIPTION = "Content-Description"

# standard, [RFC4021]
CONTENT_DISPOSITION = "Content-Disposition"

# standard, [RFC4021]
CONTENT_DURATION = "Content-Duration"

# standard, [RFC4021]
CONTENT_FEATURES = "Content-features"

# standard, [RFC4021]
CONTENT_ID = "Content-ID"

# standard, [RFC4021]
CONTENT_LANGUAGE = "Content-Language"

# standard, [RFC4021]
CONTENT_LOCATION = "Content-Location"

# standard, [RFC4021]
CONTENT_MD5 = "Content-MD5"

# standard, [RFC4021]
CONTENT_TRANSFER_ENCODING = "Content-Transfer-Encoding"

# standard, [RFC8255]
CONTENT_TRANSLATION_TYPE = "Content-Translation-Type"

# standard, [RFC4021]
CONTENT_TYPE = "Content-Type"

# standard, [RFC4021]
MIME_VERSION = "MIME-Version"
